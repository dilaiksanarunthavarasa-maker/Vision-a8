VISIONAI STUDIO V2 - ANDROID APK PROJECT

This is an Android WebView wrapper around the included local-first creator.
It has no paid API integration or subscription.

BUILD APK WITHOUT INSTALLING ANDROID STUDIO:
1. Create a free GitHub repository.
2. Upload all files/folders in this ZIP to the repository root.
3. Open the repository's Actions tab.
4. Select 'Build VisionAI Studio APK' and press 'Run workflow' (or wait for push build).
5. Open the completed workflow run, scroll to Artifacts, and download
   VisionAI-Studio-debug-apk.zip.
6. Extract app-debug.apk and install it on your Android phone. If Android asks,
   allow Chrome/GitHub/browser to install unknown apps.

IMPORTANT:
- This environment does not contain Android SDK/build-tools or Gradle, so a signed/compiled
  APK could not be produced directly here. The included GitHub Actions workflow builds
  a debug APK using GitHub's free hosted runner allowance (subject to GitHub account limits).
- This wrapper packages the V2 browser editor. It does NOT add genuine diffusion text-to-video,
  AI voice cloning, audio mixing, or guaranteed MP4 export. Genuine open-source AI generation
  still requires a compatible model runtime and substantial compute (typically a GPU computer).
- For public distribution, create your own release signing key and configure secure signing.
